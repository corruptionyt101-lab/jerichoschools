const express = require("express");
const router = express.Router();
const Poll = require("../database/pollmodel");
const User = require("../database/usermodel");
const authenticate = require("./authenticate");

router.use(authenticate);

function notifyUser(req, targetEmail, payload) {
  const io = req.app.get("io");
  if (io) io.to("user:" + targetEmail).emit("notification", payload);
}

// Staff = anyone with the admin flag (Admin Console access). Ranks are only
// cosmetic labels and do not grant anything. A poll's creator can also manage
// their own poll, even if they are later removed from staff.
async function canManagePoll(req, poll) {
  if (req.isAdmin) return true;
  if (poll.creator === req.user) return true;
  try {
    const dbUser = await User.findOne({ email: req.user });
    return !!dbUser?.admin;
  } catch (err) {
    console.error("Error checking admin flag: ", err);
    return false;
  }
}

// Shapes a poll for the frontend: adds a computed percent + volume per
// option, and total volume for the card footer. Never sends the raw bets
// list here (that's only needed in the detail view) to keep the grid light.
function shapePollSummary(poll) {
  const options = poll.options.map((o) => {
    const total = o.yesPool + o.noPool;
    return {
      _id: o._id,
      label: o.label,
      yesPercent: total > 0 ? Math.round((o.yesPool / total) * 100) : 50,
    };
  });
  const volume = poll.options.reduce((sum, o) => sum + o.yesPool + o.noPool, 0);
  return {
    _id: poll._id,
    question: poll.question,
    category: poll.category,
    icon: poll.icon,
    color: poll.color,
    options,
    volume,
    closesAt: poll.closesAt,
    resolved: poll.resolved,
    resolvedOptionIndex: poll.resolvedOptionIndex,
    resolvedSide: poll.resolvedSide,
    createdAt: poll.createdAt,
  };
}

// List all polls — unresolved (still live) ones first, newest first within
// each group.
router.get("/", async (req, res) => {
  try {
    const polls = await Poll.find({}).sort({ resolved: 1, createdAt: -1 });
    res.json(polls.map(shapePollSummary));
  } catch (err) {
    console.error("Error fetching polls: ", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Single poll, with full option pools and the requesting user's own bets on
// it (so the detail modal can show "your position" without exposing everyone
// else's bet amounts).
router.get("/:id", async (req, res) => {
  try {
    const poll = await Poll.findById(req.params.id);
    if (!poll) return res.status(404).json({ error: "Poll not found" });

    const self = await User.findOne({ email: req.user });
    const myBets = poll.bets.filter((b) => b.username === self?.username);

    res.json({
      ...shapePollSummary(poll),
      options: poll.options.map((o, i) => {
        const total = o.yesPool + o.noPool;
        return {
          _id: o._id,
          label: o.label,
          yesPercent: total > 0 ? Math.round((o.yesPool / total) * 100) : 50,
          yesPool: o.yesPool,
          noPool: o.noPool,
        };
      }),
      myBets,
      isCreator: poll.creator === req.user,
      canManage: await canManagePoll(req, poll),
    });
  } catch (err) {
    console.error("Error fetching poll: ", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Any player can start a poll — not just staff. Still requires the 21+
// self-attestation flag, same as betting, since creating a poll is part of
// the same Caps prediction game.
router.post("/", async (req, res) => {
  const self = await User.findOne({ email: req.user });
  if (!self) return res.status(404).json({ error: "User not found" });
  if (!self.username) return res.status(400).json({ error: "Set a username first" });
  if (!self.ageConfirmed21) {
    return res.status(403).json({ error: "You must confirm you're 21+ to play Polls", needsAgeConfirm: true });
  }

  const { question, category, icon, color, options, closesAt } = req.body;
  if (!question || question.trim().length < 4) {
    return res.status(400).json({ error: "A question is required" });
  }
  const cleanOptions = (Array.isArray(options) ? options : [])
    .map((label) => String(label || "").trim())
    .filter((label) => label.length > 0)
    .slice(0, 6);
  if (cleanOptions.length < 1) {
    return res.status(400).json({ error: "At least one outcome option is required" });
  }

  const poll = new Poll({
    question: question.trim().slice(0, 100),
    category: (category || "General").trim().slice(0, 30),
    icon: icon || "fa-chart-line",
    color: color || "#0088ff",
    options: cleanOptions.map((label) => ({ label })),
    creator: req.user,
    closesAt: closesAt ? new Date(closesAt) : null,
  });
  await poll.save();
  res.status(201).json(shapePollSummary(poll));
});

// Place a bet on one outcome's Yes or No side. Requires the 21+ self-
// attestation flag (see /api/auth/confirm-age) and enough Caps to cover it.
// Caps only move between the bettor and the poll's pools here — there is no
// path anywhere in this app that converts Caps into real currency.
router.post("/:id/bet", async (req, res) => {
  const { optionIndex, side, amount } = req.body;
  const amt = Number(amount);

  if (!Number.isInteger(optionIndex) || (side !== "yes" && side !== "no")) {
    return res.status(400).json({ error: "optionIndex and side (yes/no) are required" });
  }
  if (!Number.isFinite(amt) || amt < 1) {
    return res.status(400).json({ error: "Bet amount must be at least 1 Cap" });
  }

  const self = await User.findOne({ email: req.user });
  if (!self) return res.status(404).json({ error: "User not found" });
  if (!self.username) return res.status(400).json({ error: "Set a username first" });
  if (!self.ageConfirmed21) {
    return res.status(403).json({ error: "You must confirm you're 21+ to play Polls", needsAgeConfirm: true });
  }

  const poll = await Poll.findById(req.params.id);
  if (!poll) return res.status(404).json({ error: "Poll not found" });
  if (poll.creator === req.user) {
    return res.status(403).json({ error: "You can't bet on a poll you created" });
  }
  if (poll.resolved) return res.status(400).json({ error: "This poll has already been resolved" });
  if (poll.closesAt && new Date(poll.closesAt) < new Date()) {
    return res.status(400).json({ error: "Betting has closed for this poll" });
  }
  const option = poll.options[optionIndex];
  if (!option) return res.status(400).json({ error: "Invalid outcome option" });

  // Atomic debit — only succeeds if the user still has enough Caps at write
  // time, so two simultaneous bets can't both slip through on the same balance.
  const debited = await User.findOneAndUpdate(
    { email: req.user, coins: { $gte: amt } },
    { $inc: { coins: -amt } },
    { new: true }
  );
  if (!debited) return res.status(400).json({ error: "Not enough Caps for that bet" });

  if (side === "yes") option.yesPool += amt;
  else option.noPool += amt;
  poll.bets.push({ username: self.username, optionIndex, side, amount: amt });
  await poll.save();

  res.json({ coins: debited.coins, poll: shapePollSummary(poll) });
});

// Admin only — lock in the real-world outcome for one option. Winners split
// that option's whole pool (their own stake back plus a share of the losing
// side) in proportion to how much they wagered.
router.post("/:id/resolve", async (req, res) => {
  const { optionIndex, side } = req.body;
  if (!Number.isInteger(optionIndex) || (side !== "yes" && side !== "no")) {
    return res.status(400).json({ error: "optionIndex and side (yes/no) are required" });
  }

  const poll = await Poll.findById(req.params.id);
  if (!poll) return res.status(404).json({ error: "Poll not found" });
  if (!(await canManagePoll(req, poll))) {
    return res.status(403).json({ error: "Only staff or the poll's creator can set the winner" });
  }
  if (poll.resolved) return res.status(400).json({ error: "Already resolved" });
  const option = poll.options[optionIndex];
  if (!option) return res.status(400).json({ error: "Invalid outcome option" });

  const totalPool = option.yesPool + option.noPool;
  const winningPool = side === "yes" ? option.yesPool : option.noPool;

  const winningBets = poll.bets.filter((b) => b.optionIndex === optionIndex && b.side === side);
  for (const bet of winningBets) {
    const payout = winningPool > 0 ? Math.floor((bet.amount / winningPool) * totalPool) : 0;
    bet.payout = payout;
    if (payout > 0) {
      await User.updateOne({ username: bet.username }, { $inc: { coins: payout } });
    }
  }
  // Losing bets explicitly get a payout of 0 recorded, for a clean history.
  poll.bets
    .filter((b) => b.optionIndex === optionIndex && b.side !== side)
    .forEach((b) => { b.payout = 0; });

  poll.resolved = true;
  poll.resolvedOptionIndex = optionIndex;
  poll.resolvedSide = side;
  await poll.save();

  res.json(shapePollSummary(poll));
});

// Staff or the poll's creator — remove a poll. If it was never resolved,
// every bet placed on it is refunded first so nobody loses Caps. When staff
// deletes someone ELSE's poll, an optional reason can be sent — if given,
// the poll's owner gets a notification quoting it so they know why it's gone.
router.delete("/:id", async (req, res) => {
  try {
    const poll = await Poll.findById(req.params.id);
    if (!poll) return res.status(404).json({ error: "Poll not found" });
    if (!(await canManagePoll(req, poll))) {
      return res.status(403).json({ error: "Only staff or the poll's creator can delete this poll" });
    }
    if (!poll.resolved) {
      for (const bet of poll.bets) {
        await User.updateOne({ username: bet.username }, { $inc: { coins: bet.amount } });
      }
    }

    const isSelfDelete = poll.creator === req.user;
    if (!isSelfDelete) {
      const reason = String(req.body?.reason || "").trim().slice(0, 300);
      const owner = await User.findOne({ email: poll.creator });
      if (owner) {
        owner.notifications.unshift({
          type: "poll_deleted",
          text: reason
            ? `Your poll "${poll.question}" was removed by staff. Reason: ${reason}`
            : `Your poll "${poll.question}" was removed by staff.`,
        });
        await owner.save();
        notifyUser(req, owner.email, owner.notifications[0]);
      }
    }

    await poll.deleteOne();
    res.json({ message: "Poll deleted" });
  } catch (err) {
    console.error("Error deleting poll: ", err);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
