const mongoose = require("mongoose");

// Each poll can have multiple outcomes (e.g. "Oct 31-Nov 4" / "Nov 4-7"),
// and each outcome is its own tiny Yes/No market. yesPool/noPool track total
// Caps wagered on each side — percent is just yesPool / (yesPool+noPool).
// They start seeded at 50/50 so a brand-new option shows 50% instead of
// dividing by zero, and so the odds don't swing wildly on the very first bet.
const optionSchema = new mongoose.Schema(
  {
    label: { type: String, required: true, trim: true, maxlength: 60 },
    yesPool: { type: Number, default: 50 },
    noPool: { type: Number, default: 50 },
  },
  { _id: true }
);

const betSchema = new mongoose.Schema(
  {
    username: { type: String, required: true },
    optionIndex: { type: Number, required: true },
    side: { type: String, enum: ["yes", "no"], required: true },
    amount: { type: Number, required: true },
    payout: { type: Number, default: null }, // filled in once the poll resolves
  },
  { timestamps: true }
);

const schema = new mongoose.Schema(
  {
    question: { type: String, required: true, trim: true, maxlength: 100 },
    category: { type: String, default: "General", trim: true, maxlength: 30 },
    icon: { type: String, default: "fa-chart-line" },
    color: { type: String, default: "#0088ff" },
    options: { type: [optionSchema], default: [] },
    bets: { type: [betSchema], default: [] },
    creator: { type: String, required: true }, // email of the admin who made it
    closesAt: { type: Date, default: null },
    resolved: { type: Boolean, default: false },
    resolvedOptionIndex: { type: Number, default: null },
    resolvedSide: { type: String, enum: ["yes", "no", null], default: null },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Poll", schema);
