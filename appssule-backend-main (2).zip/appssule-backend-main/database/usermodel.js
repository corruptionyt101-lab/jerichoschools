const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema(
  {
    type: { type: String, required: true }, // "friend_request" | "friend_accept" | "gift" | "hub_request" | "hub_accept"
    text: { type: String, required: true },
    from: { type: String, default: null }, // the other user's username
    hubId: { type: String, default: null }, // set for hub_request/hub_accept so the UI can act on it directly
    read: { type: Boolean, default: false },
  },
  { timestamps: true }
);

const schema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
  },
  // Display identity used by the frontend (chat, friends, profile). Email stays
  // the login/JWT identity so nothing in auth.js or bin/www has to change.
  username: {
    type: String,
    trim: true,
    unique: true,
    sparse: true, // lets pre-existing accounts without a username coexist
  },
  password: {
    type: String,
    required: true,
  },
  color: {
    type: String,
    default: "lightgray",
  },
  image: {
    type: String,
    default: "none",
  },
  ip: {
    type: String,
    default: "none",
  },
  banned: {
    type: Boolean,
    default: false,
  },
  bannedReason: {
    type: String,
    default: "No reason specified.",
  },
  previousAccounts: {
    type: [String],
    default: [],
  },

  // ---- Game / profile fields ----
  bio: { type: String, default: "", maxlength: 100 },
  rep: { type: Number, default: 0 },
  coins: { type: Number, default: 100 },
  streak: { type: Number, default: 0 },
  lastClaimedAt: { type: Date, default: null },
  // Self-attested 21+ confirmation, required before betting on Polls. Caps
  // have no cash value and can never be redeemed/withdrawn as real money —
  // this just gates access to the age-restricted prediction game.
  ageConfirmed21: { type: Boolean, default: false },

  // ---- Friends (all stored as the OTHER user's username) ----
  friends: { type: [String], default: [] },
  incomingRequests: { type: [String], default: [] },
  outgoingRequests: { type: [String], default: [] },

  notifications: { type: [notificationSchema], default: [] },

  // ---- Admin Console ----
  // "admin" grants access to the console itself; "rank" is just the label
  // shown next to their name (purely cosmetic, doesn't affect permissions).
  admin: { type: Boolean, default: false },
  rank: { type: String, enum: ["Owner", "Founder", "Admin", "Dev", "Mod", "Member"], default: "Member" },
});
module.exports = mongoose.model("User", schema);
